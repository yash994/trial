

export const firebaseConfig = {
    apiKey: "AIzaSyB28-lpbuuvNlI7bE9XG9XIncQduX12N8M",
    authDomain: "final-project-7b423.firebaseapp.com",
    databaseURL: "https://final-project-7b423.firebaseio.com",
    projectId: "final-project-7b423",
    storageBucket: "final-project-7b423.appspot.com",
    messagingSenderId: "262812582768"
};



