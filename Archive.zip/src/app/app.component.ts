import { Component } from '@angular/core';
import { initializeApp, database } from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';

  constructor() {
     // Initialize Firebase
     var config = {
      apiKey: "AIzaSyB28-lpbuuvNlI7bE9XG9XIncQduX12N8M",
      authDomain: "final-project-7b423.firebaseapp.com",
      databaseURL: "https://final-project-7b423.firebaseio.com",
      projectId: "final-project-7b423",
      storageBucket: "final-project-7b423.appspot.com",
      messagingSenderId: "262812582768"
    };
    initializeApp(config);

    var root = database().ref();
    root.on('value', function(snap) {
      console.log(snap.val());
    });
  }
}
